#ifndef _PIRAMIDE_H_
#define _PIRAMIDE_H_

#include "figura.h"

struct piramide : public figura{
	piramide();
	piramide(float t);
};

#endif