#ifndef _PEON_H_
#define _PEON_H_

#include "figura.h"
using namespace std;

struct peon : public figura{
	peon();
};

#endif