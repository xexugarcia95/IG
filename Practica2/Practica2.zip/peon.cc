#include "peon.h"

peon::peon(){
	vertice.push_back(_vertex3f(40*1.0,   -1.4*40,     0.0));
    vertice.push_back(_vertex3f(40*1.0,    -1.1*40,     0.0));
    vertice.push_back(_vertex3f(40*0.5,    -0.7*40,     0.0));
    vertice.push_back(_vertex3f(40*0.4,    -0.4*40,     0.0));
    vertice.push_back(_vertex3f(40*0.4,     40*0.5,     0.0));
    vertice.push_back(_vertex3f(40*0.5,     40*0.6,     0.0));
    vertice.push_back(_vertex3f(40*0.3,     40*0.6,     0.0));
    vertice.push_back(_vertex3f(40*0.5,     40*0.8,     0.0));
    vertice.push_back(_vertex3f(40*0.55,    40*1.0,     0.0));
    vertice.push_back(_vertex3f(40*0.5,     40*1.2,     0.0));
    vertice.push_back(_vertex3f(40*0.3,     40*1.4,     0.0));

    

}