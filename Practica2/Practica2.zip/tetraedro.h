#ifndef _TETRAEDRO_H_
#define _TETRAEDRO_H_

#include "figura.h"

struct tetraedro : public figura{

	tetraedro();
	tetraedro(float t);
};

#endif